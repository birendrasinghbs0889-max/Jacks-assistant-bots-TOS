# Jack's assistant Bot — Terms & Privacy Website

A responsive, static HTML/CSS/JavaScript legal page with a dark-pink theme. It is suitable for GitHub Pages.

## Files
- `index.html` — all policy text and page structure
- `styles.css` — responsive layout and styling
- `script.js` — current year and active section highlight
- `.nojekyll` — prevents GitHub Pages Jekyll processing

## Publish with GitHub Pages
1. Sign in to GitHub and create a **public** repository, e.g. `jacks-assistant-legal`.
2. Upload `index.html`, `styles.css`, `script.js`, and `.nojekyll` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Choose branch `main` and folder `/ (root)`, then save.
6. Wait for GitHub Pages to publish. The public URL will look like `https://YOUR-USERNAME.github.io/jacks-assistant-legal/`.
7. Open that URL on a phone and computer to test it.

## Important before publishing
Search `index.html` for `[OWNER TO COMPLETE]`. Replace every placeholder with accurate information or remove the relevant line/section. In particular:
- effective and last-updated dates
- actual data read, collected, stored, logged, or shared by the bot
- hosting/database/log providers, access controls, retention and deletion
- privacy contact and how to request deletion/access
- announcement method for policy changes
- ticket/deal log retention and visibility
- giveaway eligibility and shop refund/dispute rules, if applicable

Do not claim that the bot collects or does not collect data until you have checked its source code, database, hosting, logs, and connected services. The template deliberately describes possible categories and marks unknown details.

## Customize
- Change colors in `styles.css` under `:root`.
- Change bot name and support link in `index.html`.
- The support invite currently points to `https://discord.gg/Ut35hfgyjh`.

This is a general template, not legal advice. Review it for your actual features and applicable laws before relying on it.
