document.getElementById('year').textContent = new Date().getFullYear();

// Highlight the current policy section in the side navigation.
const sections = [...document.querySelectorAll('.policy-section')];
const links = [...document.querySelectorAll('.side-link')];
if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        links.forEach(link => link.classList.toggle('active', link.getAttribute('href') === '#' + entry.target.id));
      }
    });
  }, { rootMargin: '-15% 0px -70% 0px' });
  sections.forEach(section => observer.observe(section));
}
